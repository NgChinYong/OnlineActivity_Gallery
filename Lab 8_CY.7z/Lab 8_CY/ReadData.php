<!-- <!-- Lab 8 _ Q1(C) _ Ng Chin Yong-->
 -->
<?php
//READ TEXT FILE 'r' is read
//text file   , read or else kill the process and execute "unable to open file"
$filestream =	fopen("TextFiles/data.txt", 'r') or die("unable to open file");
$char= "";

//store the file into a variable
while(!feof($filestream)) {
  $char .= "#";
  $char .= fgetc($filestream);
}
echo $char;


fclose($filestream);
?>