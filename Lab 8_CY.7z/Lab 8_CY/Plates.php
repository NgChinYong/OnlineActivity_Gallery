<!-- Lab 8 _ Q3 _ Ng Chin Yong-->

<?php
$arrplates = array (
					"A" => "Perak",		"QP" => "Kapit",
					"B" => "Selangor",	"QR" => "Sarikei",
					"C" => "Pahang",	"QS" => "Sibu/Mukah",
					"D" => "Kelantan",	"QT" => "Bintulu",
					"J" => "Johor",		"R"	 => "Perlis",
					"K" => "Kedah",		"SAC"=> "Kota Kinabalu",
					"LE"=> "Labuan",			"SB" =>"Beaufort",
					"M" => "Melaka",			"SD" =>"Lahad Datu",
					"N" => "Negeri Sembilan",	"SK" =>"Kudat",
					"P" => "Pulau Pinang",		"SS" =>"Sandakan",
					"QA"=> "Kuching",			"ST" =>"Tawau",
					"QB"=> "Sri Aman /Betong",	"SU" =>"Keningau",
					"QC"=> "Kota Samarahan",	"T" =>"Terrenganu",
					"QL"=>"Limbang/Lawas",		"V" =>"Kuala Lumpur",
					"QM"=> "Miri",				"SSA" => "Sandakan"
					);
					
$filestream =	fopen("TextFiles/plates.txt", 'r') or die("unable to open file");
$plate= "";

//store the file into a variable
while(!feof($filestream)) {
  $plate .= fgets($filestream);
  $plate .= "#";
}
$plateRecords = explode("#",$plate);


//remove all plate digit
foreach ($plateRecords as $p ) 
{
	$word[] = preg_replace('/[0-9]+/', '', $p);
}


//arr plate shorcut , Compare the plate letter with prefix and store the value in array
foreach($word as $w) {
	$str ="";
foreach ($arrplates as $ap => $value)
{
	
		if (strpos($w , $ap) !== false) 
		{
			$str .= $value;
			$str .= ",";
		}
	
	}
	$new[] = $str;
}


array_map(function($pr, $n){
    echo $pr . " = ";
    echo $n . "<br>";
}, $plateRecords, $new);






?>