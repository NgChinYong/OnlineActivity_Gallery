<!-- Lab 8 _ Q4 _ Ng Chin Yong-->

<?php

$filestream =	fopen("TextFiles/sales_25-10-2017.txt", 'r') or die("unable to open file");
$all= "";

//store the file into a variable
while(!feof($filestream)) {
  $all .= fgets($filestream);
  $all .= " ";
}

fclose($filestream);
//seperate all in a cell sequently
$seperatedAll = explode(" ", $all);
//print_r($seperatedAll);

//store all accordingly to associative array (product, qty, uprice,total, subtotal)
$cart = array (
				"product" => array() ,  //0
				"qty" => array() ,		//1
				"uprice" => array() ,	//2
				"total" => array() 		//3
			  );


//categories the data (product, qty, uprice, total)

foreach ($seperatedAll as $sa)
{
	
		if (strpos($sa , "RM") !== false) //got RM is total price
		{	
			 $NEWsa = substr($sa, 2);
			 $cart["total"][] = $NEWsa;
			 
		}
		elseif (strpos($sa , "x") !== false)
		{
			$Xsa = substr($sa, 0 , strpos ($sa, 'x'));
			$Xsa2 = substr($sa ,(strpos ($sa, 'x'))+1);
			if(!empty($Xsa)) //before x is qty
			{
			$cart["qty"][] = $Xsa;	
			}
			if(!empty($Xsa2))  //after x is uprice
			{
			$cart["uprice"][] = $Xsa2;	
			}
		}
		else //else is product
		{
			$cart["product"][] = $sa;
		}
	
}

//print_r($cart);

?>
<style>
table {border-collapse:collapse;}
table, th, td {border:1px solid black;}
th {background-color:pink; width:200px}
td {text-align:center}
</style>
<table>
<tr><th>DATE</th><td colspan="2"> <?php echo "&nbsp;".date('j-m-y');?></td></tr>
<tr><th>ITEM NAME</th><th>UNIT PRICE (RM)</th><th>QUANTITY (SOLD)</th></tr>
<?php
//display in table 
$subtotal = 0;
array_map(function($p, $u, $q , $t){
    global $subtotal; 
	$subtotal += $t; //sum up total into subtotal
	echo "<tr><td>$p</td><td>$u</td><td>$q</td></tr>";
	
}, $cart["product"], $cart["uprice"],$cart["qty"], $cart["total"]);


?>
<tr><th style="text-align:right"colspan="2">TOTAL (RM) &nbsp;</th><td><?php echo $subtotal;?></td></tr>
</table>







