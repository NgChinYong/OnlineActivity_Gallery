<!-- Lab 8 _ Q1(D) _ Ng Chin Yong-->

<?php
//READ TEXT FILE 'r' is read
//text file   , read or else kill the process and execute "unable to open file"
$filestream =	fopen("TextFiles/pages.txt", 'r') or die("unable to open file");
$page="";

while(!feof($filestream)) {
  $page .= fgetc($filestream); 
}

$pages = preg_split('/\s+/', $page);
$index = 0;
$about = 0;
$sitemap = 0;
$login = 0;
$contactus= 0 ;
$faq = 0;
$def = 0;

foreach ($pages as $p){
	
	switch ($p) {
	case "index.php": $index++; break;
	case "about.php": $about++; break;
	case "sitemap.php": $sitemap++;break;
	case "login.php": $login++; break;
	case "contactus.php": $contactus++; break;
	case "faq.php": $faq++; break;
	
	}
}

echo "	
		index.php = $index <br>
		about.php = $about <br>
		sitemap.php = $sitemap <br>
		login.php = $login <br>
		contactus.php = $contactus <br>
		faq.php = $faq <br>
		
	 ";
fclose($filestream);
?>
