<!-- Lab 8 _ Q4 _ Ng Chin Yong-->

<?php
$filestream =	fopen("TextFiles/numberSets.txt", 'r') or die("unable to open file");
$num = fgets($filestream);
//echo $num;
$set = explode(";", $num); //seperate the sets
$counter=0;
foreach ($set as $s) 
{
	$set2[$counter]= preg_replace('/[^0-9.]+/', '',explode(",",$s));
	$counter++;
}
//average set
foreach ($set2 as $s2) 
{
	$average[]=round((array_sum($s2)/count($s2)),2);
}
//smallest num
foreach ($set2 as $s2) 
{
	$smallest[]=min($s2);
}
//largest num
foreach ($set2 as $s2) 
{
	$largest[]=max($s2);
}
echo "This is num <br>";
print_r($num);

echo "<br><br>This is set <br>";
print_r($set);

echo "<br><br>This is set2 <br>";
print_r($set2);

echo "<br><br>This is average <br>";
print_r($average);

echo "<br><br>This is lowest <br>";
print_r($smallest);

echo "<br><br>This is largest <br>";
print_r($largest);


?>

<h1>This is set</h1>

<?php

array_map(function($ave, $sma, $lar , $se){
    $new = str_replace("$sma","<strong><span style='color:red'>$sma</span></strong>",$se);
	echo "<p> $new: largest($lar) ~ average($ave)</p>";
	
}, $average , $smallest , $largest , $set); 

?>











