<!-- Lab 8 _ Q5 _ Ng Chin Yong-->
<?php
$filestream =	fopen("TextFiles/birthdates.txt", 'r') or die("unable to open file");
$birthdates = fgets($filestream);
//echo $birthdates."<br>";
$arrBirth = explode (" " , $birthdates);
//print_r($arrBirth);

foreach ($arrBirth as $ab)
{
	$arrMonth[] =preg_replace('/[^\pL@,.;]+/', '',substr($ab ,(strpos ($ab, '-')+1),(strrpos ($ab, '-')-1))); //PL property for letters
}
//print_r($arrMonth);
$jan="";$feb="";$mar="";$apr="";$may="";$jun="";$jul="";$aug="";$sep="";$oct="";$nov="";$dec="";
foreach($arrMonth as $am)
{
	if (strcasecmp($am, "jan") == 0) 
		{
			$jan .= " &#127874; ";
		}
	elseif (strcasecmp($am, "feb") == 0) 
		{
			$feb .= " &#127874; ";
		}
	elseif (strcasecmp($am, "mar") == 0) 
		{
			$mar .= " &#127874; ";
		}
	elseif (strcasecmp($am, "apr") == 0) 
		{
			$apr .= " &#127874; ";
		}
	elseif (strcasecmp($am, "may") == 0) 
		{
			$may .= " &#127874; ";
		}
	elseif (strcasecmp($am, "jun") == 0) 
		{
			$jun .= " &#127874; ";
		}
	elseif (strcasecmp($am, "jul") == 0) 
		{
			$jul .= " &#127874; ";
		}
	elseif (strcasecmp($am, "aug") == 0) 
		{
			$aug .= " &#127874; ";
		}
	elseif (strcasecmp($am, "sep") == 0) 
		{
			$sep .= " &#127874; ";
		}
	elseif (strcasecmp($am, "oct") == 0) 
		{
			$oct .= " &#127874; ";
		}
	elseif (strcasecmp($am, "nov") == 0) 
		{
			$nov .= " &#127874; ";
		}
	elseif (strcasecmp($am, "dec") == 0) 
		{
			$dec .= " &#127874; ";
		}
	
}

?>
<style>table {border: 1px solid black;} th{width: 60px; text-align:left ; font-weight:normal} td{width:600px}</style>
<table>
<tr><th>JAN</th><td><?php echo $jan;?></td></tr>
<tr><th>FEB</th><td><?php echo $feb;?></td></tr>
<tr><th>MAR</th><td><?php echo $mar;?></td></tr>
<tr><th>APR</th><td><?php echo $apr;?></td></tr>
<tr><th>MAY</th><td><?php echo $may;?></td></tr>
<tr><th>JUN</th><td><?php echo $jun;?></td></tr>
<tr><th>JUL</th><td><?php echo $jul;?></td></tr>
<tr><th>AUG</th><td><?php echo $aug;?></td></tr>
<tr><th>SEP</th><td><?php echo $sep;?></td></tr>
<tr><th>OCT</th><td><?php echo $oct;?></td></tr>
<tr><th>NOV</th><td><?php echo $nov;?></td></tr>
<tr><th>DEC</th><td><?php echo $dec;?></td></tr>
</table>