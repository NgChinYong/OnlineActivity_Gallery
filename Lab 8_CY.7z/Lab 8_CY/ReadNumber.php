<!-- Lab 8 _ Q1(B) _ Ng Chin Yong-->

<?php
//READ TEXT FILE 'r' is read
//text file   , read or else kill the process and execute "unable to open file"
$filestream =	fopen("TextFiles/numbers.txt", 'r') or die("unable to open file");
$numbers="";

//store the file into a variable
while(!feof($filestream)) {
  $numbers .= fgetc($filestream);
}

//save number in array by spliting `
$num = explode ("`",$numbers);

//check the array is odd or even
foreach ($num as $n) {
	if ($n%2 ==0) 
	{
		echo "$n is even <br>";
	}
	else 
	{
		echo "$n is odd <br>";
	}
}
fclose($filestream);
?>