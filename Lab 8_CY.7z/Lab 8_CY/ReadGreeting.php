<!-- Lab 8 _ Q1(A) _ Ng Chin Yong-->

<?php
//READ TEXT FILE 'r' is read
//text file   , read or else kill the process and execute "unable to open file"
$filestream =	fopen("TextFiles/greetings.txt", 'r') or die("unable to open file");
echo "<h1>".fgets($filestream)."</h1>";
fclose($filestream);
?>
