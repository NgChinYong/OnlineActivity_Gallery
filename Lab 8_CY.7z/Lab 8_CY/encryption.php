<!-- Lab 8 _ Q2 _ Ng Chin Yong-->

<?php
$plain="";
$filestream = fopen("TextFiles/data.txt", 'r') or die("unable to open file");
while(!feof($filestream)) {
  $plain .= fgetc($filestream);
}

echo $plain;

$normal = array ('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
$encrypt = array ('E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','A','B','C','D');
$test = $plain;
$arrtest = str_split($test);
$entest ="";


foreach ($arrtest as $a) {
$counter = 0;
	while( $counter < count($normal))
	{
		if ( $a == $normal[$counter])
		{
			$entest .= "$encrypt[$counter]";
		}
		else if ($a == " ")
		{
			$entest .= " ";
		}
		
			$counter++;
	}
}
echo "<br><br>Encrpted : <br>$entest <br><br> Ciphertext.txt have been saved.";
$myfile = fopen("ciphertext.txt", "w")or die("Unable to open file!");
$txt = $entest;
fwrite($myfile, $txt);
fclose($myfile);
?>